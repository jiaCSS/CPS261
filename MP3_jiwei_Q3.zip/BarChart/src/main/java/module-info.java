module application.barchart {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens application.barchart to javafx.fxml;
    exports application.barchart;
}