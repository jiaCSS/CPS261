package application.barchart;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.input.ZoomEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.Scanner;

public class HelloController implements Initializable {
    @FXML
    private FlowPane paneView;
    @FXML
    private BarChart<Integer, String> barChart;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        loadData();

    }

    private void loadData() {

        paneView.getChildren().clear();
        CategoryAxis yAxis = new CategoryAxis();
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("Scores");
//        xAxis.setTickLabelRotation(90);
        yAxis.setLabel("State");

        BarChart barChart = new BarChart(xAxis, yAxis);
        barChart.setTitle("State 2018-2019 Scores");

        XYChart.Series series = new XYChart.Series();
        series.setName("2018-2019 State Scores");
        try{

            File file = new File(getClass().getResource("hockey.txt").toURI());

            Scanner sc = new Scanner(file);
//            String line = sc.nextLine();
//            String[] arrOfStr = line.split(",", 2);
//            System.out.println(arrOfStr[0]);
//            System.out.println(Integer.parseInt(arrOfStr[1]));

            while(sc.hasNextLine()){

                String line = sc.nextLine();
                String[] arrOfStr = line.split(",", 2);
                series.getData().add(new XYChart.Data<>(Integer.parseInt(arrOfStr[1]), arrOfStr[0]));

            }

            sc.close();
        }catch (Exception e){

            e.printStackTrace();
        }

        barChart.getData().add(series);
        barChart.setStyle("-fx-color-fill: blue");//I don't know how to
        // change color of barchart
        paneView.getChildren().add(barChart);

        barChart.prefWidthProperty().bind(paneView.widthProperty());
        barChart.prefHeightProperty().bind(paneView.heightProperty());

    }
}