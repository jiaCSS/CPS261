package application.barchart;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class HelloController implements Initializable {
    @FXML
    private Pane paneView;
    @FXML
    private BarChart<Integer, String> barChart;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        loadData();

    }

    private void loadData() {

        paneView.getChildren().clear();
        CategoryAxis yAxis = new CategoryAxis();
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("Scores");
//        xAxis.setTickLabelRotation(90);
        yAxis.setLabel("State");

        BarChart barChart = new BarChart(xAxis, yAxis);
        barChart.setTitle("State 2018-2019 Scores");

        XYChart.Series series = new XYChart.Series();
        series.setName("2018-2019 State Scores");
        try{

            File file = new File("./resources/application/barchart/hockey.txt");
            Scanner sc = new Scanner(file);
            sc.next();
            System.out.println(sc.next());
            sc.close();
        }catch (Exception e){

            e.printStackTrace();
        }

        series.getData().add(new XYChart.Data<>(300, "MI"));
        series.getData().add(new XYChart.Data<>(200, "CA"));
        series.getData().add(new XYChart.Data<>(100, "UL"));
        series.getData().add(new XYChart.Data<>(150, "IL"));

        barChart.getData().add(series);




        paneView.getChildren().add(barChart);

    }
}