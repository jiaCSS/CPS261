public class BadIndentationException extends RuntimeException {

	public BadIndentationException(String error){

		super(error);

	}


}
