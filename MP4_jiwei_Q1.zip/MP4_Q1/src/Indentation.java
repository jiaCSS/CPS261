import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;


public class Indentation {

	static  Stack<Integer> stackInt = new Stack<>();;
	String fileName;



	public static int findNonWhiteSpace(String line) {

		for(int i = 0; i<line.length(); i++){

			if(line.charAt(i) != ' '){

				return i;
			}
		}

		return -1;
	}

	public void pushStack(String line, int lineCounter){

		int index = findNonWhiteSpace(line);
		if(index == -1) return;
		if(stackInt.isEmpty()){

			stackInt.push(index);
		}
		else{

			while(index >= stackInt.peek()){

				stackInt.push(index);
				return;
			}
			while(stackInt.peek() > index){

				stackInt.pop();
			}
			if(stackInt.peek() != index){

				System.out.println("This is not properly indentation file" + fileName);
				throw new BadIndentationException("error at line: " + lineCounter);
			}

		}
	}

	public void readFile(String fileName) {

			Scanner sc = null;

		try {

			File file = new File(fileName);
			sc = new Scanner(file);
			int lineCounter = 1;

			while (sc.hasNextLine()) {

				String line = sc.nextLine();
				System.out.println(lineCounter +":" + line);
				pushStack(line, lineCounter);

				lineCounter ++;

			}

			if(stackInt.peek() == 0){

				System.out.println("this is good indentation file: " + fileName);
			}

			sc.close();//close file
		}
		catch (BadIndentationException e){

			System.out.println(e);
		}
		catch (FileNotFoundException e) {
			System.out.println("Cannot find the file!" + fileName);
		}


	}

	public static void main(String[] args){

		Indentation indentation = new Indentation();
		indentation.readFile("src/indentation_file5.txt");

	}





}


