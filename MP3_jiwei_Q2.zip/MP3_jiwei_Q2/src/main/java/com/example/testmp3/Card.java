package com.example.testmp3;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Card {

    public Card(){

    }


    public ArrayList<String> cards(){

        ArrayList<String> cards = new ArrayList<>();
        for(int i = 0; i<54; i++){

            cards.add(String.valueOf(i+1));
        }
        java.util.Collections.shuffle(cards);

        return cards;
    }

}
