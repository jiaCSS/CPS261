package com.example.testmp3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    private ImageView view1;
    @FXML
    private ImageView view2;
    @FXML
    private ImageView view3;
    @FXML
    private ImageView view4;
    @FXML
    private Button refresh;

    Image image1;
    Image image2;
    Image image3;
    Image image4;
    Image backOfCard = new Image(getClass().getResourceAsStream("backCard" +
            ".png"));

    private Card card = new Card();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        view1.setImage(backOfCard);
        view2.setImage(backOfCard);
        view3.setImage(backOfCard);
        view4.setImage(backOfCard);


    }

    public void view1OnMouse(){

        String fileName = card.cards().get(0)+ ".png";
        image1 = new Image(getClass().getResourceAsStream("card/" +fileName));
        view1.setImage(image1);
    }

    public void view2OnMouse(){

        String fileName = card.cards().get(1)+ ".png";
        image2 = new Image(getClass().getResourceAsStream("card/" +fileName));
        view2.setImage(image2);
    }

    public void view3OnMouse(){

        String fileName = card.cards().get(2) + ".png";
        image3 =
                new Image(getClass().getResourceAsStream("card/" + fileName));
        view3.setImage(image3);
    }

    public void view4OnMouse(){

        String fileName = card.cards().get(3) + ".png";;
        image4 = new Image(getClass().getResourceAsStream("card/" +fileName));
        view4.setImage(image4);

    }

    public void onRefresh(ActionEvent e){

        System.out.println("hello");
        view1.setImage(backOfCard);
        view2.setImage(backOfCard);
        view3.setImage(backOfCard);
        view4.setImage(backOfCard);


        }


}