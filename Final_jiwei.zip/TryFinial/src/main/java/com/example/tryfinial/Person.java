package com.example.tryfinial;

import java.util.Random;

public class Person {

	private int randomNum;
	Random random =new Random();
	public int getRandomNum() {
		randomNum = random.nextInt(6)+1;
		return randomNum;
	}

	public void setRandomNum(int randomNum) {

		this.randomNum = randomNum;

	}
	public Person(){


	}

}
