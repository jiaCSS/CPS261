package com.example.tryfinial;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class HistoryController implements Initializable {

	@FXML private TableView<PersonHistory> tableView;
	@FXML
	private TableColumn<PersonHistory, String> nameColumn;
	@FXML
	private TableColumn<PersonHistory, String> winOrLoseColumn;
	@FXML
	private TableColumn<PersonHistory, LocalDate> dateColumn;
	@FXML
	private TableColumn<PersonHistory, Integer> scoresColumn;
	@FXML
	private TextArea summaryText;
	@FXML private Label testName;
	@FXML private TextFlow textFlow;
	@FXML private Button toHistoryTableView;
	PersonHistory personHistory = new PersonHistory();
	Parent root;
	private Stage stage;
	private Scene scene;
	String name1, name2;
	List<PersonHistory> tempList1 = new ArrayList<>();
	List<PersonHistory> tempList2 = new ArrayList<>();
	int counter = 1;

	private HelloController helloCountroller;


	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {

		nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
		dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
		scoresColumn.setCellValueFactory(new PropertyValueFactory<>("scores"));
		winOrLoseColumn.setCellValueFactory(new PropertyValueFactory<>(
				"winOrLose"));


	}

//	public ObservableList<PersonHistory> getPeople() throws IOException {
//		System.out.println("getPeople()");
//		System.out.println(tempList1.size());
//		ObservableList<PersonHistory> people =
//				FXCollections.observableArrayList();
//
//		people.addAll(tempList1);
//		people.addAll(tempList2);
//
////		people.add(new PersonHistory("ken", LocalDateTime.now(), 70, "Lose"));
//		return people;
//	}
	public void switchToPlayPage(ActionEvent e) throws IOException {

		FXMLLoader loader = new FXMLLoader(getClass().getResource("play" +
				".fxml"));

		HistoryController historyController = loader.getController();
		root = loader.load();
		stage =(Stage) ((Node)e.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setTitle("Welcome To Play Page");
		stage.setScene(scene);
		stage.show();
	}

	public void getOnTable(ObservableList<PersonHistory> tempPeople) throws IOException {

		System.out.println("getONTable History start");
		List<List<String>> tempPeopleList = new ArrayList<>();
		FileWriter fileWriter= new FileWriter("fileBind.txt", true);
		BufferedOutputStream bw =
				new BufferedOutputStream(new FileOutputStream("filehistory" +
						".txt"));

		try{

			tableView.setItems(tempPeople);

		}
		catch (Exception e){

			e.printStackTrace();
		}
		PersonHistory person = new PersonHistory();
		for(int i = 0; i<tableView.getItems().size(); i++){

			tempPeopleList.add(new ArrayList<>());
			tempPeopleList.get(i).add(tableView.getItems().get(i).getName());
			tempPeopleList.get(i).add(String.valueOf(tableView.getItems().get(i).getDate()));
			tempPeopleList.get(i).add(String.valueOf(tableView.getItems().get(i).getScores()));
			tempPeopleList.get(i).add(tableView.getItems().get(i).getWinOrLose());
		}
		for(int i = 0; i< tempPeopleList.size();i++){
			for(int j = 0; j < tempPeopleList.get(i).size(); j++){

				bw.write(tempPeopleList.get(i).get(j).getBytes());
				fileWriter.write(tempPeopleList.get(i).get(j) + " ");
			}
			bw.write("\n".getBytes());
			fileWriter.write("\n");

		}
		bw.flush();
		bw.close();
		fileWriter.close();
	}

	public void setArrayList(HelloController helloController) throws IOException {

		this.helloCountroller = helloController;
		helloController.getArrayListAndWriteToFile();

	}
	public void setHistoryDataObserv(HelloController helloController){

		this.helloCountroller = helloController;
		helloController.getHistoryData("filewriter.txt");
	}

	public void switchToHistoryPage(ActionEvent e){
		HelloController helloController = new HelloController();
		ObservableList<PersonHistory> historyDataTable =
				getHistoryData();
		tableView.refresh();
		tableView.setItems(historyDataTable);
		tableView.getSortOrder().add(dateColumn);
		showHistoryResults();
	}

	public ObservableList<PersonHistory>  getHistoryData(){

		helloCountroller = new HelloController();
		ObservableList<PersonHistory> historyDataTable=
				helloCountroller.getHistoryData("filewriter.txt");

		return historyDataTable;
	}

	public void showHistoryResults(){
		System.out.println("how history starts");
		ObservableList<PersonHistory> historyDataTable =
				getHistoryData();

		Map<String, Integer> historyMap = new HashMap<>();

		for(int i = 0; i< historyDataTable.size(); i++){

			String name = historyDataTable.get(i).getName();
			String winorLose = historyDataTable.get(i).getWinOrLose();

			if(winorLose.toLowerCase().contains("win")){

				if(historyMap.containsKey(name)){


					counter = historyMap.get(name).intValue() + 1;
					historyMap.put(name,counter);
					System.out.println("name"+name+ "counter" + counter + historyDataTable.get(i).getDate());
				}
				else{

					historyMap.put(name,1);
				}
			}

		}
		summaryText.clear();
		historyMap.entrySet().stream()
				.forEach(e-> summaryText.appendText((e.getKey() + " has: " + e.getValue() + " wins\n")));

		System.out.println("how history starts");
	}

	public void getWinnerUsingMap ( Map<String, Integer> tempMapList){


		tempMapList.entrySet().stream().forEach(e -> summaryText.appendText(
				" " + e.getKey() + " has : " + e.getValue() +" wins\n"));

	}





}
