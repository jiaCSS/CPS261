package com.example.tryfinial;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class HelloController implements Initializable {
	@FXML private TextField score1Text;
	@FXML private TextField score2Text;
	@FXML private TextField inputName1;
	@FXML private TextField inputName2;
	@FXML private Button rollButton;
	@FXML private Button holdButton;
	@FXML private TextField turnTotalText;
	@FXML private ImageView imageView;
	@FXML private Button historyPageButton;
	@FXML private TextField turnsState;
	@FXML private TextArea gameRules;
	@FXML private Button NewGameButton;
	int turnTotal =0;
	int scores1 = 0;
	int scores2 = 0;
	boolean play1Turn;
	private Parent root;
	private Stage stage;
	private Scene scene;
	int finalScore1;
	int finalScore2;
	String state1;
	String state2;
	String name1;
	String name2;
	private ObservableList<PersonHistory> personData =
			FXCollections.observableArrayList();

	private ObservableList<PersonHistory> historyPersonData =
			FXCollections.observableArrayList();
	LocalDateTime date;
	private Map<String, Integer> counterMap = new HashMap<>();
	int counter1 = 1;//counter first player winner numbers
	int counter2 = 1;//counter second player winner numbers

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		firstTurn();
		imageView.setImage(new Image(getClass().getResourceAsStream("dice" +
				".png")));

		gameRules.setText("A: 2-6 continue or hold. if push hold, " +
				"turn sum add to scores respectively and out game\nB: 1 out " +
				"game " +
				"turn sum =" +
				" 0 \nC: downGame when don't continue game\nD: winner: >= 30");
		date = getDateTime();
	}

	public void firstTurn(){

		Person person1 = new Person();
		int randomInitial = person1.getRandomNum();
		if(randomInitial ==2 || randomInitial ==3 || randomInitial == 4){
			play1Turn = true;
			turnsState.setText("Name1 turn");
		}
		else {
			play1Turn = false;
			turnsState.setText("Name2 turn");
		}
		System.out.println(randomInitial + "initialize");
	}

	public LocalDateTime getDateTime(){

		LocalDateTime tempDate = LocalDateTime.now();
		tempDate = tempDate.truncatedTo(ChronoUnit.SECONDS);
//		System.out.println(tempDate.truncatedTo(ChronoUnit.HOURS));
//		System.out.println(tempDate.truncatedTo(ChronoUnit.MINUTES));
		System.out.println(tempDate.truncatedTo(ChronoUnit.SECONDS));
		return tempDate;
	}

	public void getImage(int random){

		imageView.setImage(new Image(getClass().getResourceAsStream("dice" +
						"/dice" + random + ".png"
				)));

	}
	public void onRoll(ActionEvent e){

		Person person = new Person();
		int random = person.getRandomNum();
		System.out.println(random);

		if(scores1 >=30 || scores2 >=30){
			turnsState.setText("Game Over");
			checkWinner(scores1, scores2);
			rollButton.setDisable(true);
			holdButton.setDisable(true);

		}
		else{
			getImage(random);
			check(random);
		}
	}

	// this is important method. after click onHold, turn sum =0;
	//for  saving time reason, 30 pints is the winner.

	public void onHold ( ActionEvent e){

		if(scores1 <30 && scores2 <30){
			if (turnTotalText.getText() == "0") {
				if(play1Turn)
					scores1 = scores1;
				else
					scores2 = scores2;
			}
			if(play1Turn){
				scores1 = scores1 + turnTotal;
				score1Text.setText(String.valueOf(scores1));
				play1Turn = false;
				turnsState.setText(inputName1.getText() + " out "+ inputName2.getText()+" turn");

			}
			else{
				scores2 = scores2 + turnTotal;
				score2Text.setText(String.valueOf(scores2));
				play1Turn = true;
				turnsState.setText(inputName2.getText() + " out " + inputName1.getText()+" turn");
			}
			turnTotal = 0;
		}
		else{
			//flag to restart a game or to history page
			rollButton.setDisable(true);
			holdButton.setDisable(true);
			checkWinner(scores1, scores2);

		}
	}

	//check rules
	public void check(int random){

		if(play1Turn){
			turnsState.setText(inputName1.getText() + " turn");
			if(random !=1){
				turnTotal = turnTotal + random;
				turnTotalText.setText(String.valueOf(turnTotal));
			}
			else{
				turnTotal = 0;
				turnTotalText.setText("0");
				play1Turn = false;
				turnsState.setText(inputName1.getText() + " out " + inputName2.getText()+" turn");
			}
		}
		else{

			turnsState.setText(inputName2.getText() + " turn");
			if(random !=1){
				turnTotal = turnTotal + random;
				turnTotalText.setText(String.valueOf(turnTotal));
			}
			else{

				turnTotal = 0;
				turnTotalText.setText("0");
				play1Turn = true;
				turnsState.setText(inputName2.getText() + " out "+ inputName1.getText()+" turn");
			}
		}

	}

	//Check winner results and show in text box.
	public void checkWinner(int score1, int scores2){
		if(score1>scores2){
			System.out.println(inputName1.getText() + "wins");
			System.out.println(inputName2.getText() + "loses");
			turnsState.setText(inputName1.getText() + " wins " + inputName2.getText() +
					" loses");

		}
		else if(score1 < scores2){
			System.out.println(inputName2.getText() + "wins");
			System.out.println(inputName1.getText() + "loses");
			turnsState.setText(inputName1.getText() + " loses " + inputName2.getText() + " wins");

		}
		else{
			System.out.println(inputName1.getText() + "wins");
			System.out.println(inputName2.getText() + "wins");
			turnsState.setText("Both win");

		}

	}
	public String getState1Result(int finalScore1, int finalScore2){

		if(finalScore1 <30 && finalScore2 <30){

				state1= "Lose";
			}
			else{

				if(finalScore1 > finalScore2)
					state1 = "Win";
				else if (finalScore1 < finalScore2)
					state1 = "Lose";
				else
					state1 = "Win";
			}

		System.out.println("state1" + state1);
		return state1;
	}

	public String getState2Result(int finalScore1, int finalScore2){

			if(finalScore1 <30 && finalScore2 <30){

				state2 = "Lose";
			}
			else{

				if(finalScore1 > finalScore2)
					state2 = "Lose";
				else if(finalScore1 < finalScore2)
					state2 = "Win";
				else
					state2 = "Win";
			}


		System.out.println(state2 + "state2");
		return state2;
	}
	public int getFinalScore1(int scores1){

		finalScore1 = scores1;
		System.out.println(finalScore1+ "finalScore1");

		return finalScore1;
	}
	public int getFinalScore2(int scores2){

		finalScore2 = scores2;
		System.out.println(finalScore2 + "finalScore2");

		return finalScore2;
	}


	//while click new game, it means down game and add info to observable
	// List and obtain winner counter map.
	public void downGame(){

		name1 = inputName1.getText();
		name2 = inputName2.getText();
		finalScore1 = getFinalScore1(scores1);
		finalScore2 = getFinalScore2(scores2);
		state1 = getState1Result(scores1, scores2);
		state2 = getState2Result(scores1, scores2);
		if(finalScore1 !=0 || finalScore2 != 0){
			personData.add(new PersonHistory(name1, date, finalScore1, state1 ));
			personData.add(new PersonHistory(name2, date, finalScore2, state2 ));

			//obtain counterMap
			if(state1.toLowerCase().contains("win")){
				if(counterMap.containsKey(name1)){

					counter1 +=1;
					counterMap.put(name1, counter1);
				}
				else{

					counterMap.put(name1, 1);
				}
			}
			if(state2.toLowerCase().contains("win")){
				if(counterMap.containsKey(name2)){

					counter2 +=1;
					counterMap.put(name2, counter2);
				}
				else{

					counterMap.put(name2, 1);
				}
			}
		}

		turnTotalText.setText("0");
		turnsState.setText(name1 + " " + state1 + " " + name2 +" " + state2);
	}

	//when click current history page or new game

	public void toHistoryOrNewPageSetting(){

			downGame();
			scores1=0;// this important to reset game and replay.
			scores2 = 0;//this important to reset game and replay.
			turnTotalText.setText("0");
			score1Text.setText("0");
			score2Text.setText("0");
			turnsState.clear();
			firstTurn();//reset who will be first person to roll dice
			date = getDateTime();//reset start play time

	}
	public void NewGameAction(ActionEvent e){

		rollButton.setDisable(false);
		holdButton.setDisable(false);
		toHistoryOrNewPageSetting();

	}

	//To write current  and history data to file
	public List<List<String>> getArrayListAndWriteToFile() throws IOException {
		ObservableList<PersonHistory> tempObservList =
				getObservableListPeople();
		System.out.println("getWinnerList");
		PersonHistory personHistory = new PersonHistory();
		List<List<String>> arrListPeople = new ArrayList<>();
		FileWriter fw = new FileWriter("filewriter.txt", true);
//		BufferedOutputStream bw =
//				new BufferedOutputStream(new FileOutputStream("bufferwrite" +
//						".txt"));

		for(int i = 0; i<tempObservList.size();i++){

			personHistory = tempObservList.get(i);

			arrListPeople.add(new ArrayList<>());
			arrListPeople.get(i).add(personHistory.getName());
			arrListPeople.get(i).add(" " + personHistory.getDate());
			arrListPeople.get(i).add(" " + personHistory.getScores());
			arrListPeople.get(i).add(" " + personHistory.getWinOrLose());
			String states = arrListPeople.get(i).get(3);
			String names = arrListPeople.get(i).get(0);
			System.out.println(names + states + "before if");
			System.out.println(inputName1.getText()+"inputname1.gettext()");

		}

		System.out.println(arrListPeople.size() + "arrListPeople");

		for(int i = 0; i<arrListPeople.size(); i++){

			for(int j = 0; j< arrListPeople.get(i).size(); j++){

//				bw.write(arrListPeople.get(i).get(j).getBytes());
//				bw.write(" ".getBytes());
				fw.write(arrListPeople.get(i).get(j));
				fw.write(" ");
			}

//			bw.write("\n".getBytes());
			fw.write("\n");
		}
//		bw.flush();
//		bw.close();
		fw.close();

		return arrListPeople;
	}



	public ObservableList<PersonHistory> getObservableListPeople (){

		System.out.println("getObservableListPeople");
		for(PersonHistory personObser : personData){
			System.out.println(personObser.getName());
			System.out.println(personObser.getDate());
			System.out.println(personObser.getScores());
			System.out.println(personObser.getWinOrLose());
		}
		return personData;
	}

	//get current winner counter Map;
	public Map<String, Integer> getCounterMapFromMethod(){

		return counterMap;
	}

	//Get history data read from file
	public ObservableList<PersonHistory> getHistoryData(String fileName){

		File file = new File(fileName);
		ObservableList<PersonHistory> historyDataObservableList =
				FXCollections.observableArrayList();
		try {

			Scanner scanner = new Scanner(file);
			while(scanner.hasNextLine()){

				String line = scanner.nextLine();
				String[] tempPeopleDetails = line.split(" ");
				Stream<String> tempStream = Stream.of(tempPeopleDetails);

				List<String> resultsPeopleDetails =
						(List<String>) tempStream
								.collect(Collectors.toList());

				//get rid of " " space
				for(int i = 0; i < resultsPeopleDetails.size();i++){

					if(resultsPeopleDetails.get(i) == ""){

						resultsPeopleDetails.remove(resultsPeopleDetails.get(i));
					}
				}
				//add to history observableList.
				String detailName = resultsPeopleDetails.get(0);

				//reset LocalDateTime format, it is important while read file.
				LocalDateTime detailDate =
						LocalDateTime.parse
								(String.format(resultsPeopleDetails.get(1), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

				int detailScore = Integer.parseInt(resultsPeopleDetails.get(2));

				String detailWinOrLose = resultsPeopleDetails.get(3);

				historyDataObservableList.add(new PersonHistory(detailName, detailDate,
						detailScore, detailWinOrLose));

			}
			scanner.close();

		} catch (FileNotFoundException e) {

			throw new RuntimeException(e);
		}

		return historyDataObservableList;
	}

	//Switch to Current History page
	public void switchToHistory(ActionEvent e) throws IOException {

		downGame();
		toHistoryOrNewPageSetting();

		ObservableList<PersonHistory> historyDataObservableList =
				getHistoryData(
				"filewriter.txt");
		FXMLLoader loader = new FXMLLoader(getClass().getResource("history" +
				".fxml"));
		root = loader.load();
		HistoryController historyController = loader.getController();

		//get current run data
		historyController.getOnTable(getObservableListPeople());
		historyController.getWinnerUsingMap(getCounterMapFromMethod());

		//get History data
		//call back from history Controller, to get history data from hello
		// controller;
		historyController.setArrayList(this);
		historyController.setHistoryDataObserv(this);


		stage =(Stage) ((Node)e.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setTitle("Welcome To History Page");
		stage.setScene(scene);
		stage.show();
	}

}
