package com.example.tryfinial;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

import java.time.LocalDateTime;

public class PersonHistory {

	protected SimpleStringProperty name;
	protected SimpleStringProperty winOrLose;
	protected LocalDateTime date;
	protected SimpleIntegerProperty scores;

	public String getName() {
		return name.get();
	}

	public SimpleStringProperty nameProperty() {
		return name;
	}

	public void setName(String name) {
		this.name.set(name);
	}

	public String getWinOrLose() {
		return winOrLose.get();
	}

	public SimpleStringProperty winOrLoseProperty() {
		return winOrLose;
	}

	public void setWinOrLose(String winOrLose) {
		this.winOrLose.set(winOrLose);
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public int getScores() {
		return scores.get();
	}

	public SimpleIntegerProperty scoresProperty() {
		return scores;
	}

	public void setScores(int scores) {
		this.scores.set(scores);
	}

	public PersonHistory(String name,
						 LocalDateTime date, int scores, String winOrLose) {
		this.name = new SimpleStringProperty(name);
		this.winOrLose =new SimpleStringProperty( winOrLose);
		this.date = date;
		this.scores = new SimpleIntegerProperty(scores);
	}
	public PersonHistory(){


	}

}
