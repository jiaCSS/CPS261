import java.io.*;
import java.util.*;
public class HashSetStudy {
	private HashSet<String> dicHashSet = new HashSet<>();
	private TreeSet<String> missSpelling = new TreeSet<>();
	private ArrayList<String> notInDicMissSpell = new ArrayList<>();
	int lineCounter = 1;
	StringTokenizer st;

	public void readToDicHashSet (){

		Scanner sc = null;
		String fileName = "src/dictionary.txt";
		try{

			File file = new File(fileName);
			sc = new Scanner(file);
			while(sc.hasNextLine()){

				String line = sc.nextLine();
				st = new StringTokenizer(line,  " \t,.;:%'\"");
				while(st.hasMoreTokens()){

					dicHashSet.add(st.nextToken());
				}
			}

			sc.close();
//			System.out.println(dicHashSet);

		}
		catch (FileNotFoundException e){

			System.out.println("file is not fund!" + fileName);
		}
	}

	public void checkSpell(String fileName) throws FileNotFoundException{

		BufferedReader br = null;
		FileReader fr = null;
		String line;
		String word;
		LinkedHashSet<String> wordList = new LinkedHashSet<>();
		try{

			fr = new FileReader(fileName);
			br = new BufferedReader(fr);
			while((line = br.readLine()) != null){

				StringTokenizer st = new StringTokenizer(line," ()-\t,.;:%'\"");
				while(st.hasMoreTokens()){

					word = st.nextToken().toLowerCase();
					wordList.add(word);

					if(Character.isDigit(word.charAt(0)))
						wordList.remove(word);
				}
			}

			Iterator iterator = wordList.iterator();

			while(iterator.hasNext()){

				optionCheck((String) iterator.next());
			}
			br.close();
			fr.close();
		}
		catch (FileNotFoundException e){

			System.out.println("file not found" + fileName);
		}
		catch (IOException e){

			e.printStackTrace();
		}

	}

	public void optionCheck(String word)
			throws FileNotFoundException{


		Scanner scanner = new Scanner(System.in);
		String subWords = word.substring(0, word.length()-1);
		HashSet<String> subSetWord = new HashSet<>();
		char last = word.charAt(word.length()-1);
		boolean subStr = word.contains("s");//I think the this part shouldn't
		// be do it because of single verb would be plural too.

		if(!dicHashSet.contains(word) && (!missSpelling.contains(word))){

			notInDicMissSpell.add(word);
			System.out.println( lineCounter + ": **"+ word + "** is not in " +
					"the" +
					" " +
					"dictionary and Miss Spelling List\nAdd " +
					"to " +
					"dictionary: D\nMiss spelling: M\nNeither: " +
					"N" );
			String input = scanner.nextLine();
			switch (input){

				case "D":
					dicHashSet.add(word);
					break;
				case "M":
					missSpelling.add(word);
					break;
				case "N":
					break;
			}

			lineCounter++;
		}
	}

	public void sortList(){

		Collections.sort(notInDicMissSpell);
		int counter = 0;
		System.out.println("After sorted list: ");
		for(int i =0; i<notInDicMissSpell.size();i++){

			System.out.println(notInDicMissSpell.get(i));
			counter++;
		}
		System.out.println("The total number is : " + counter);
	}



}
