import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {


	public static void main(String[] args) throws FileNotFoundException {

		String fileName = "src/Russia.txt";
		String fileName1 = "src/Ukraine.txt";
		System.out.println("Processing the file: " + fileName1);

		try{

			HashSetStudy hashSetStudy = new HashSetStudy();
			hashSetStudy.readToDicHashSet();
			hashSetStudy.checkSpell(fileName1);
			hashSetStudy.sortList();

		}

		catch (FileNotFoundException e){

			System.out.println("No File Found" + fileName1);
		}

	}


}